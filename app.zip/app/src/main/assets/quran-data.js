/* Quran text. Replace this file with the output of tools/make_quran_data.py (see QURAN-DATA-README.txt). */
window.QURAN_TEXT=null;
