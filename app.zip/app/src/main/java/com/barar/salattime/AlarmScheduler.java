package com.barar.salattime;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmScheduler {
    static final String PREFS = "barar_alarms", KEY = "events", KEY_COUNT = "count";
    static final int MAX = 60;

    public static boolean canExact(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
    }

    private static PendingIntent pending(Context c, int id, String title, String body) {
        Intent in = new Intent(c, AlarmReceiver.class);
        in.putExtra("title", title);
        in.putExtra("body", body);
        return PendingIntent.getBroadcast(c, id, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        int n = c.getSharedPreferences(PREFS, 0).getInt(KEY_COUNT, 0);
        if (am == null) return;
        for (int i = 0; i < n; i++) am.cancel(pending(c, i, "", ""));
    }

    public static void scheduleAll(Context c, String json) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            cancelAll(c);
            JSONArray a = new JSONArray(json), keep = new JSONArray();
            long now = System.currentTimeMillis();
            int n = 0;
            for (int i = 0; i < a.length() && n < MAX; i++) {
                JSONObject o = a.getJSONObject(i);
                long t = o.getLong("t");
                if (t <= now) continue;
                PendingIntent pi = pending(c, n, o.optString("title"), o.optString("body"));
                try {
                    if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                } catch (SecurityException se) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                }
                keep.put(o);
                n++;
            }
            c.getSharedPreferences(PREFS, 0).edit().putString(KEY, keep.toString()).putInt(KEY_COUNT, n).apply();
        } catch (Exception ignored) { }
    }

    public static void rescheduleFromPrefs(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, 0);
        scheduleAll(c, sp.getString(KEY, "[]"));
    }
}
